from flask import Flask, request, render_template, redirect, url_for
from werkzeug.utils import secure_filename
import os
import re
import PyPDF2
import json

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load job requirements
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
job_requirements_path = os.path.join(BASE_DIR, 'model', 'job_requirements.json')

with open(job_requirements_path, 'r') as f:
    JOB_REQUIREMENTS = json.load(f)

# Text cleaning
def clean_text(txt):
    return re.sub(r'\s+', ' ', txt).strip()

# PDF text extraction
def extract_text_from_pdf(file_path):
    with open(file_path, 'rb') as pdf_file:
        reader = PyPDF2.PdfReader(pdf_file)
        text = ''.join(page.extract_text() or "" for page in reader.pages)
    return text

# Resume details extraction
def extract_details(resume_text):
    email = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', resume_text)
    phone = re.search(r'\b\d{10}\b|\+\d{1,3}\s\d{10}', resume_text)
    name = re.search(r'\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)+', resume_text)  # Assuming names start with capital letters
    
    return (
        name.group(0) if name else "Not Found",
        email.group(0) if email else "Not Found",
        phone.group(0) if phone else "Not Found"
    )

# Match score and skills calculation
def calculate_match_score_and_skills(resume_text, job_requirements):
    skills = []
    score = 0
    for skill in job_requirements["skills"]:
        if re.search(r'\b' + re.escape(skill) + r'\b', resume_text, re.IGNORECASE):
            skills.append(skill)
            score += 1
    match_score = (score / len(job_requirements["skills"])) * 100 if job_requirements["skills"] else 0
    return match_score, skills

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    files = request.files.getlist('resumes')
    job_role = request.form.get('job')
    
    if not files or not job_role:
        return redirect(url_for('index'))

    results = []
    for file in files:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        file.save(file_path)

        resume_text = clean_text(extract_text_from_pdf(file_path))
        name, email, phone = extract_details(resume_text)
        match_score, skills = calculate_match_score_and_skills(resume_text, JOB_REQUIREMENTS.get(job_role, {"skills": []}))

        results.append({
            "filename": filename,
            "name": name,
            "email": email,
            "phone": phone,
            "skills": skills,
            "score": match_score
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    return render_template('results.html', results=results, job_role=job_role)

if __name__ == '__main__':
    app.run(debug=True)
