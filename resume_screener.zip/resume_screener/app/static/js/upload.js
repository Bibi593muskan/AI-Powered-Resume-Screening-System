document.addEventListener('DOMContentLoaded', () => {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('resumes');
    const fileBadge = document.getElementById('file-count-badge');
    const uploadForm = document.getElementById('upload-form');
    const progressContainer = document.getElementById('progress-container');
    const progressFill = document.getElementById('progress-fill');
    const progressStatus = document.getElementById('progress-status');
    const progressPercentage = document.getElementById('progress-percentage');
    const logConsole = document.getElementById('log-console');
    const btnSubmit = document.getElementById('btn-submit-upload');

    if (!dropzone || !fileInput || !uploadForm) return;

    // Trigger click on file input when dropzone is clicked
    dropzone.addEventListener('click', () => {
        fileInput.click();
    });

    // Handle file input change
    fileInput.addEventListener('change', () => {
        updateFileBadge();
    });

    // Drag-over highlights
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
        }, false);
    });

    // Handle file drops
    dropzone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            fileInput.files = files;
            updateFileBadge();
        }
    }, false);

    function updateFileBadge() {
        const count = fileInput.files.length;
        if (count > 0) {
            fileBadge.innerText = `${count} file(s) selected`;
            fileBadge.classList.remove('d-none');
            logMessage(`Files selected: ${Array.from(fileInput.files).map(f => f.name).join(', ')}`);
        } else {
            fileBadge.classList.add('d-none');
        }
    }

    function logMessage(text, isError = false) {
        const timestamp = new Date().toLocaleTimeString();
        const color = isError ? '#ef4444' : '#10b981';
        logConsole.innerHTML += `<div style="color: ${color}">[${timestamp}] ${text}</div>`;
        logConsole.scrollTop = logConsole.scrollHeight;
    }

    // Form Submission (AJAX with custom upload status simulations)
    uploadForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const jobId = document.getElementById('job_id').value;
        const runName = document.getElementById('run_name').value;
        const files = fileInput.files;

        if (!jobId) {
            alert('Please select a target job profile.');
            return;
        }

        if (files.length === 0) {
            alert('Please select or drop at least one resume.');
            return;
        }

        // Hide form contents, show progress console
        btnSubmit.disabled = true;
        uploadForm.style.opacity = '0.5';
        progressContainer.style.display = 'block';
        logConsole.innerHTML = ''; // clear console

        logMessage('Initializing resume parser service...');
        updateProgress(10, 'Uploading files...');

        const formData = new FormData();
        formData.append('job_id', jobId);
        formData.append('run_name', runName);
        for (let i = 0; i < files.length; i++) {
            formData.append('resumes', files[i]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/upload', true);

        // Track upload progress
        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                // Upload is fast (local), represent up to 40% as upload progress
                const percent = Math.round((e.loaded / e.total) * 40);
                updateProgress(percent, `Uploading resumes (${percent}%)`);
                if (percent === 40) {
                    logMessage('Upload complete. Parsing documents (PDF/DOCX)...');
                }
            }
        });

        xhr.onload = function() {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);
                updateProgress(80, 'Analyzing candidate experience levels...');
                logMessage('Document extraction complete.');
                
                setTimeout(() => {
                    updateProgress(90, 'Matching candidates against criteria...');
                    logMessage('NLP skills search completed.');
                    logMessage('Calculating similarity metrics using Cosine vector engines...');
                }, 800);

                setTimeout(() => {
                    updateProgress(100, 'Screening complete!');
                    logMessage('Successfully matched candidates.');
                    if (res.errors && res.errors.length > 0) {
                        res.errors.forEach(err => logMessage(err, true));
                    }
                    logMessage('Redirecting to results workspace...');
                    
                    setTimeout(() => {
                        window.location.href = res.redirect_url;
                    }, 1200);
                }, 1600);

            } else {
                let errMsg = 'An error occurred during screening.';
                try {
                    const res = JSON.parse(xhr.responseText);
                    errMsg = res.error || errMsg;
                    if (res.errors && res.errors.length > 0) {
                        res.errors.forEach(err => logMessage(err, true));
                    }
                } catch(e) {}
                
                updateProgress(100, 'Screening failed');
                logMessage(`Error: ${errMsg}`, true);
                btnSubmit.disabled = false;
                uploadForm.style.opacity = '1';
            }
        };

        xhr.onerror = function() {
            updateProgress(100, 'Network failure');
            logMessage('Network error occurred during server communication.', true);
            btnSubmit.disabled = false;
            uploadForm.style.opacity = '1';
        };

        xhr.send(formData);
    });

    function updateProgress(value, text) {
        progressFill.style.width = `${value}%`;
        progressPercentage.innerText = `${value}%`;
        progressStatus.innerText = text;
    }
});
