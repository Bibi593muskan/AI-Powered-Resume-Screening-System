document.addEventListener('DOMContentLoaded', () => {
    // 1. Handle Candidate Profile Review Modal Populating
    const reviewButtons = document.querySelectorAll('.btn-review-profile');
    
    reviewButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Retrieve data attributes
            const name = button.getAttribute('data-name');
            const email = button.getAttribute('data-email');
            const phone = button.getAttribute('data-phone');
            const exp = button.getAttribute('data-experience');
            
            // JSON fields (need safety checks)
            let education = [];
            let skillsMatched = [];
            let skillsMissing = [];
            let skillsOther = [];
            
            try { education = JSON.parse(button.getAttribute('data-education') || '[]'); } catch(e) {}
            try { skillsMatched = JSON.parse(button.getAttribute('data-skills-matched') || '[]'); } catch(e) {}
            try { skillsMissing = JSON.parse(button.getAttribute('data-skills-missing') || '[]'); } catch(e) {}
            try { skillsOther = JSON.parse(button.getAttribute('data-skills-other') || '[]'); } catch(e) {}
            
            const scoreOverall = button.getAttribute('data-score-overall');
            const scoreSim = button.getAttribute('data-score-sim');
            const scoreSkills = button.getAttribute('data-score-skills');
            const scoreExp = button.getAttribute('data-score-exp');
            const rawText = button.getAttribute('data-raw-text');

            // Populate Modal Text Nodes
            document.getElementById('modal-name').innerText = name;
            document.getElementById('modal-email').innerText = email;
            document.getElementById('modal-phone').innerText = phone;
            document.getElementById('modal-experience').innerText = `${exp} Years`;
            document.getElementById('modal-raw-text').innerText = rawText || 'No text extracted.';
            
            // Initials badge
            const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            document.getElementById('modal-initials').innerText = initials || 'C';

            // Populate Education Bullet points
            const edContainer = document.getElementById('modal-education');
            edContainer.innerHTML = '';
            if (education.length > 0) {
                education.forEach(item => {
                    edContainer.innerHTML += `<li><i class="fa-solid fa-check text-secondary me-2"></i>${item}</li>`;
                });
            } else {
                edContainer.innerHTML = '<li class="text-muted italic">No educational institutions parsed.</li>';
            }

            // Populate Score Widgets
            document.getElementById('modal-score-overall').innerText = `${scoreOverall}%`;
            document.getElementById('modal-bar-overall').style.width = `${scoreOverall}%`;
            
            // Set dynamic overall bar color based on score tier
            const overallBar = document.getElementById('modal-bar-overall');
            overallBar.className = 'progress-bar-fill'; // reset class
            if (scoreOverall >= 85) {
                overallBar.style.background = 'var(--gradient-success)';
            } else if (scoreOverall >= 70) {
                overallBar.style.background = 'var(--gradient-purple)';
            } else if (scoreOverall >= 50) {
                overallBar.style.background = 'var(--gradient-cyan)';
            } else {
                overallBar.style.background = 'var(--danger)';
            }

            document.getElementById('modal-score-sim').innerText = `${scoreSim}%`;
            document.getElementById('modal-score-skills').innerText = `${scoreSkills}%`;
            document.getElementById('modal-score-exp').innerText = `${scoreExp}%`;

            // Populate Skills cloud lists
            const matchedContainer = document.getElementById('modal-skills-matched');
            matchedContainer.innerHTML = '';
            if (skillsMatched.length > 0) {
                skillsMatched.forEach(s => {
                    matchedContainer.innerHTML += `<span class="skill-badge skill-match">${s}</span>`;
                });
            } else {
                matchedContainer.innerHTML = '<span class="text-muted small">No direct criteria matched.</span>';
            }

            const missingContainer = document.getElementById('modal-skills-missing');
            missingContainer.innerHTML = '';
            if (skillsMissing.length > 0) {
                skillsMissing.forEach(s => {
                    missingContainer.innerHTML += `<span class="skill-badge skill-missing">${s}</span>`;
                });
            } else {
                missingContainer.innerHTML = '<span class="text-success small">No missing skills. Perfect!</span>';
            }

            const otherContainer = document.getElementById('modal-skills-other');
            otherContainer.innerHTML = '';
            if (skillsOther.length > 0) {
                skillsOther.forEach(s => {
                    otherContainer.innerHTML += `<span class="skill-badge skill-general">${s}</span>`;
                });
            } else {
                otherContainer.innerHTML = '<span class="text-muted small">None identified.</span>';
            }
        });
    });

    // 2. Candidate Status Selector Handler (AJAX updates)
    const statusUpdaters = document.querySelectorAll('.status-updater');
    statusUpdaters.forEach(select => {
        // Change row coloring classes based on status selection
        updateRowColoring(select.closest('tr'), select.value);

        select.addEventListener('change', () => {
            const resultId = select.getAttribute('data-result-id');
            const newStatus = select.value;
            const row = select.closest('tr');

            // Send AJAX update request
            fetch(`/api/result/${resultId}/status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status: newStatus })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update layout
                    updateRowColoring(row, newStatus);
                    row.setAttribute('data-status', newStatus);
                    
                    // Create basic ephemeral notification alert
                    showToastNotification(`Candidate status set to ${newStatus}`);
                } else {
                    alert('Failed to update candidate status: ' + data.error);
                }
            })
            .catch(err => {
                console.error('Status update failed:', err);
                alert('Network error updating status.');
            });
        });
    });

    function updateRowColoring(rowElement, status) {
        if (!rowElement) return;
        
        // Remove active class colors
        rowElement.style.borderLeft = 'none';
        
        if (status === 'Shortlisted') {
            rowElement.style.borderLeft = '4px solid var(--success)';
            rowElement.style.backgroundColor = 'rgba(16, 185, 129, 0.02)';
        } else if (status === 'Rejected') {
            rowElement.style.borderLeft = '4px solid var(--danger)';
            rowElement.style.backgroundColor = 'rgba(239, 68, 68, 0.01)';
        } else {
            rowElement.style.borderLeft = 'none';
            rowElement.style.backgroundColor = 'transparent';
        }
    }

    // 3. Grid Table Filtering by Status
    const statusFilter = document.getElementById('status-filter');
    if (statusFilter) {
        statusFilter.addEventListener('change', () => {
            const selectedStatus = statusFilter.value;
            const rows = document.querySelectorAll('#results-table tbody tr');
            
            rows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                if (selectedStatus === 'ALL' || rowStatus === selectedStatus) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // Toast helper
    function showToastNotification(message) {
        // Create dynamic small notification banner
        let container = document.getElementById('toast-container-custom');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container-custom';
            container.style.position = 'fixed';
            container.style.bottom = '2rem';
            container.style.right = '2rem';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = 'glass-card p-3 mb-2';
        toast.style.background = 'rgba(15, 17, 26, 0.95)';
        toast.style.color = '#fff';
        toast.style.borderLeft = '4px solid var(--primary)';
        toast.style.minWidth = '220px';
        toast.style.boxShadow = 'var(--shadow-premium)';
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        toast.innerHTML = `<i class="fa-solid fa-circle-check text-primary me-2"></i>${message}`;

        container.appendChild(toast);
        
        // Trigger reflow & fade in
        setTimeout(() => toast.style.opacity = '1', 50);
        
        // Fade out & delete
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    }
});
