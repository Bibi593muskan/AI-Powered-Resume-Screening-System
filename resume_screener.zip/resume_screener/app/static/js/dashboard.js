document.addEventListener('DOMContentLoaded', () => {
    const scoresCanvas = document.getElementById('scoresDoughnutChart');
    const skillsCanvas = document.getElementById('skillsBarChart');

    if (!scoresCanvas || !skillsCanvas) return;

    // Fetch analytical stats from API
    fetch('/api/analytics/dashboard')
        .then(response => response.json())
        .then(data => {
            renderScoresChart(data.scores_chart);
            renderSkillsChart(data.skills_chart);
        })
        .catch(err => {
            console.error('Error fetching analytics charts data:', err);
        });

    function renderScoresChart(chartData) {
        // Dark theme harmonies
        const colors = [
            'rgba(16, 185, 129, 0.75)',  # Excellent (Green)
            'rgba(99, 102, 241, 0.75)',  # Good (Indigo)
            'rgba(245, 158, 11, 0.75)',  # Average (Amber)
            'rgba(239, 68, 68, 0.75)'    # Poor (Red)
        ];
        const borders = [
            '#10b981', '#6366f1', '#f59e0b', '#ef4444'
        ];

        new Chart(scoresCanvas, {
            type: 'doughnut',
            data: {
                labels: chartData.labels,
                datasets: [{
                    data: chartData.data,
                    backgroundColor: colors,
                    borderColor: borders,
                    borderWidth: 1.5,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#e5e7eb',
                            font: {
                                size: 10,
                                family: "'Plus Jakarta Sans', sans-serif"
                            },
                            boxWidth: 12,
                            padding: 10
                        }
                    }
                },
                cutout: '70%'
            }
        });
    }

    function renderSkillsChart(chartData) {
        // Fallback placeholder if no data is present
        const labels = chartData.labels.length > 0 ? chartData.labels : ['No Data'];
        const values = chartData.data.length > 0 ? chartData.data : [0];

        new Chart(skillsCanvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Applicant Frequency',
                    data: values,
                    backgroundColor: 'rgba(6, 182, 212, 0.65)',
                    borderColor: '#06b6d4',
                    borderWidth: 1.5,
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',  // Horizontal bar chart
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false  // Hide dataset label
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.05)'
                        },
                        ticks: {
                            color: '#9ca3af',
                            stepSize: 1,
                            font: { size: 9 }
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#e5e7eb',
                            font: { 
                                size: 9,
                                weight: '500'
                            }
                        }
                    }
                }
            }
        });
    }
});
