import os
from flask import Flask, redirect, url_for
from flask_login import LoginManager
from app.models import db, User
from config import Config

login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)

    # Ensure required directories exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(app.config['BASE_DIR'], 'data'), exist_ok=True)

    # Import Blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.jobs import jobs_bp
    from app.routes.sessions import sessions_bp
    from app.routes.api import api_bp

    # Register Blueprints
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
    app.register_blueprint(jobs_bp, url_prefix='/jobs')
    app.register_blueprint(sessions_bp, url_prefix='/sessions')
    app.register_blueprint(api_bp, url_prefix='/api')

    # Root redirect
    @app.route('/')
    def index():
        return redirect(url_for('auth.login'))

    # Context processor to inject modern utilities or current year
    @app.context_processor
    def inject_now():
        from datetime import datetime
        return {'current_year': datetime.utcnow().year}

    # Create tables if database doesn't exist
    with app.app_context():
        db.create_all()

    return app
