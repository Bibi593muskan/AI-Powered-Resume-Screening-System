from datetime import datetime
import json
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """Recruiter / User details for authentication."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    
    # Relationships
    jobs = db.relationship('JobDescription', backref='recruiter', lazy=True, cascade="all, delete-orphan")
    sessions = db.relationship('ScreeningSession', backref='recruiter', lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class JobDescription(db.Model):
    """Job vacancy templates matching criteria."""
    __tablename__ = 'job_descriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    department = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=False)
    min_experience = db.Column(db.Integer, default=0)
    required_skills = db.Column(db.Text, nullable=True)  # Comma-separated string
    education_criteria = db.Column(db.String(150), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    sessions = db.relationship('ScreeningSession', backref='job', lazy=True, cascade="all, delete-orphan")

    def get_skills_list(self):
        if not self.required_skills:
            return []
        return [s.strip().lower() for s in self.required_skills.split(',') if s.strip()]


class ScreeningSession(db.Model):
    """Tracks a screening run event for auditing and history."""
    __tablename__ = 'screening_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    run_name = db.Column(db.String(200), nullable=False)  # e.g., "Software Engineer Bulk Upload - June 21"
    run_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Completed')  # 'Processing', 'Completed', 'Failed'
    
    job_id = db.Column(db.Integer, db.ForeignKey('job_descriptions.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    results = db.relationship('ScreeningResult', backref='session', lazy=True, cascade="all, delete-orphan")


class Candidate(db.Model):
    """Parsed profile of a parsed resume file."""
    __tablename__ = 'candidates'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(200), nullable=False)
    filepath = db.Column(db.String(300), nullable=False)
    candidate_name = db.Column(db.String(150), nullable=True)
    email = db.Column(db.String(120), nullable=True)
    phone = db.Column(db.String(50), nullable=True)
    extracted_text = db.Column(db.Text, nullable=True)
    skills = db.Column(db.Text, nullable=True)  # JSON-serialized list of strings
    experience_years = db.Column(db.Float, default=0.0)
    education = db.Column(db.Text, nullable=True)  # JSON-serialized list of education items
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    screening_results = db.relationship('ScreeningResult', backref='candidate', lazy=True, cascade="all, delete-orphan")

    def get_skills(self):
        if not self.skills:
            return []
        try:
            return json.loads(self.skills)
        except Exception:
            return []

    def set_skills(self, skills_list):
        self.skills = json.dumps(skills_list)

    def get_education(self):
        if not self.education:
            return []
        try:
            return json.loads(self.education)
        except Exception:
            return []

    def set_education(self, education_list):
        self.education = json.dumps(education_list)


class ScreeningResult(db.Model):
    """Screening metrics link table connecting Candidate to a Job and Session."""
    __tablename__ = 'screening_results'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('screening_sessions.id'), nullable=False)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.id'), nullable=False)
    
    overall_score = db.Column(db.Float, nullable=False)      # Score 0 - 100
    similarity_score = db.Column(db.Float, nullable=False)    # Text Cosine Similarity
    skill_score = db.Column(db.Float, nullable=False)         # Skill matches ratio
    experience_score = db.Column(db.Float, nullable=False)    # Exp matched ratio
    
    status = db.Column(db.String(50), default='Screened')     # 'Screened', 'Shortlisted', 'Rejected'
    notes = db.Column(db.Text, nullable=True)
    matched_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_skills_analysis(self, job_skills_list):
        """Analyzes which skills matched, which are missing, and other auxiliary candidate skills."""
        cand_skills = self.candidate.get_skills()
        job_skills_set = set(s.strip().lower() for s in job_skills_list if s.strip())
        cand_skills_set = set(s.strip().lower() for s in cand_skills if s.strip())
        
        matched = list(job_skills_set.intersection(cand_skills_set))
        missing = list(job_skills_set.difference(cand_skills_set))
        other = list(cand_skills_set.difference(job_skills_set))
        
        return {
            'matched': sorted(matched),
            'missing': sorted(missing),
            'other': sorted(other)
        }
