import re
import spacy
from spacy.matcher import PhraseMatcher

# Try loading the spacy model. If it fails, we will fall back to basic text parsing.
try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    # Model might not be downloaded yet, we can load it dynamically or handle it.
    nlp = None

# A comprehensive predefined skill taxonomy list (expanded with tech and soft skills)
SKILLS_TAXONOMY = [
    # Programming Languages
    "python", "java", "c++", "c#", "c", "javascript", "typescript", "ruby", "php", "go", "golang", "rust", "swift", "kotlin", "scala", "html", "css", "sql", "r", "bash", "shell",
    # Frameworks & Libraries
    "flask", "django", "fastapi", "spring", "react", "angular", "vue", "svelte", "jquery", "bootstrap", "tailwind", "next.js", "node.js", "express", "pandas", "numpy", "scipy", "scikit-learn", "sklearn", "tensorflow", "pytorch", "keras", "spacy", "nltk", "opencv", "matplotlib", "seaborn",
    # Cloud & DevOps
    "aws", "gcp", "azure", "docker", "kubernetes", "jenkins", "git", "github", "gitlab", "ansible", "terraform", "ci/cd", "devops", "linux", "nginx", "apache",
    # Databases
    "sqlite", "postgresql", "mysql", "mongodb", "redis", "cassandra", "oracle", "mariadb", "firebase",
    # Concepts & Methodologies
    "machine learning", "deep learning", "nlp", "natural language processing", "computer vision", "artificial intelligence", "ai", "data science", "data engineering", "big data", "agile", "scrum", "project management", "software engineering", "oop", "rest api", "graphql", "microservices", "system design"
]

def clean_text(text):
    """Cleans text of extra whitespaces and special characters for basic analysis."""
    if not text:
        return ""
    # Normalize whitespaces
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def extract_email(text):
    """Extract email addresses from text using a robust regex pattern."""
    pattern = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+'
    matches = re.findall(pattern, text)
    return matches[0] if matches else None

def extract_phone(text):
    """Extract phone numbers from text using a flexible international pattern."""
    # Matches formats: +1-234-567-8900, (123) 456-7890, 1234567890, etc.
    pattern = r'(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
    matches = re.findall(pattern, text)
    return matches[0] if matches else None

def extract_name(text):
    """Extract candidate name. Uses spaCy NER PERSON tag or falls back to first lines."""
    if not text:
        return "Unknown Candidate"
        
    global nlp
    if nlp:
        # We only process the first 1000 characters to find the candidate's name (normally at the top)
        doc = nlp(text[:1000])
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                # Basic sanity checks (e.g. name shouldn't have newlines or be extremely long)
                name = ent.text.strip()
                if 2 < len(name.split()) < 5 and "\n" not in name:
                    return name
                    
    # Fallback: Clean the first line of text if it looks like a name
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    if lines:
        first_line = lines[0]
        # Ignore lines containing "resume", "cv", "page" or standard labels
        if len(first_line.split()) <= 4 and not any(kw in first_line.lower() for kw in ["resume", "cv", "curriculum", "page", "profile", "contact"]):
            return first_line
            
    return "Unknown Candidate"

def extract_skills(text):
    """Extract skills matching our skills taxonomy."""
    if not text:
        return []
    
    extracted = set()
    text_lower = text.lower()
    
    # Simple word boundary matching for safety and reliability
    for skill in SKILLS_TAXONOMY:
        # Match multi-word or single-word skills safely with word boundaries
        # Special cases like C++, C#, .NET need custom escaping
        escaped_skill = re.escape(skill)
        if skill in ["c++", "c#", ".net"]:
            pattern = r'(?:^|[\s,;:\(\)])' + escaped_skill + r'(?:$|[\s,;:\(\)])'
        else:
            pattern = r'\b' + escaped_skill + r'\b'
            
        if re.search(pattern, text_lower):
            extracted.add(skill)
            
    return sorted(list(extracted))

def extract_experience(text):
    """Estimate total years of experience from text using numeric sentence context."""
    if not text:
        return 0.0
        
    total_exp = 0.0
    text_lower = text.lower()
    
    # Regex to look for phrases like "3 years of experience", "5+ years exp", "2 yrs of working experience"
    # Matches patterns like: [number] [years/yrs] [of/in] [experience/exp]
    patterns = [
        r'(\d+(?:\.\d+)?)\s*(?:\+)?\s*(?:years?|yrs?)\s*(?:of|in)?\s*(?:experience|exp|working|work)',
        r'(?:experience|exp|work)\s*:\s*(\d+(?:\.\d+)?)\s*(?:years?|yrs?)'
    ]
    
    found_years = []
    for pattern in patterns:
        matches = re.findall(pattern, text_lower)
        for match in matches:
            try:
                found_years.append(float(match))
            except ValueError:
                pass
                
    if found_years:
        # Return the maximum mentioned experience block (usually the total)
        total_exp = max(found_years)
        if total_exp > 40.0:  # Sanity cap
            total_exp = 0.0
            
    # Secondary check: if no explicit pattern, count duration blocks if possible, or default to 0
    return total_exp

def extract_education(text):
    """Extract degree titles and major institutions (universities)."""
    if not text:
        return []
        
    education_items = []
    text_lower = text.lower()
    
    # Degress keywords
    degrees = [
        r'\b(?:b\.?s\.?c?|b\.?tech|b\.?e\.?|b\.?a\.?|b\.?b\.?a\.?|bachelor(?:\'s)?)\b',
        r'\b(?:m\.?s\.?c?|m\.?tech|m\.?e\.?|m\.?a\.?|m\.?b\.?a\.?|master(?:\'s)?)\b',
        r'\b(?:ph\.?d\.?|doctorate)\b',
        r'\bdiploma\b'
    ]
    
    # Institution keywords
    institutions = [
        r'\b(?:university|college|institute|academy|school of)\b'
    ]
    
    # Parse sentences to find combinations or stand-alone education records
    lines = text.split('\n')
    for line in lines:
        line_clean = line.strip()
        if not line_clean:
            continue
            
        # Match degree or university names on lines containing typical education headers
        match_deg = any(re.search(deg, line_clean.lower()) for deg in degrees)
        match_inst = any(re.search(inst, line_clean.lower()) for inst in institutions)
        
        if (match_deg or match_inst) and len(line_clean) < 150:
            education_items.append(line_clean)
            
    return education_items[:5]  # Limit to top 5 entries for layout safety

def analyze_resume(raw_text):
    """Runs the full NLP pipeline on raw text to build candidate profile details."""
    clean = clean_text(raw_text)
    
    # Extract entities
    name = extract_name(raw_text)
    email = extract_email(clean)
    phone = extract_phone(clean)
    skills = extract_skills(raw_text)
    experience = extract_experience(clean)
    education = extract_education(raw_text)
    
    return {
        'name': name,
        'email': email,
        'phone': phone,
        'skills': skills,
        'experience_years': experience,
        'education': education,
        'raw_text': raw_text
    }
