import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def calculate_text_similarity(job_desc_text, resume_text):
    """Computes the TF-IDF and Cosine Similarity between Job Description and Resume."""
    if not job_desc_text or not resume_text:
        return 0.0
        
    try:
        # Standard english tfidf vectorizer with stop words removed
        vectorizer = TfidfVectorizer(stop_words='english')
        tfidf = vectorizer.fit_transform([job_desc_text, resume_text])
        
        # Calculate cosine similarity
        sim = cosine_similarity(tfidf[0:1], tfidf[1:2])
        score = float(sim[0][0]) * 100.0
        return min(max(score, 0.0), 100.0)
    except Exception as e:
        print(f"Error calculating similarity: {str(e)}")
        return 0.0

def calculate_skill_score(job_skills_list, candidate_skills_list):
    """Calculates percentage of required skills present in candidate skills."""
    if not job_skills_list:
        # If no skills are specified, candidate gets full skill marks
        return 100.0
        
    required_count = len(job_skills_list)
    
    # Normalize comparison arrays
    job_skills_set = set(s.strip().lower() for s in job_skills_list if s.strip())
    cand_skills_set = set(s.strip().lower() for s in candidate_skills_list if s.strip())
    
    if not job_skills_set:
        return 100.0
        
    matched_skills = job_skills_set.intersection(cand_skills_set)
    matched_count = len(matched_skills)
    
    score = (matched_count / len(job_skills_set)) * 100.0
    return min(max(score, 0.0), 100.0)

def calculate_experience_score(min_exp_required, candidate_exp_years):
    """Calculates experience suitability score."""
    if min_exp_required <= 0:
        # No experience required, candidate gets full experience marks
        return 100.0
        
    if candidate_exp_years >= min_exp_required:
        return 100.0
        
    # Partial score if candidate has less experience
    score = (candidate_exp_years / min_exp_required) * 100.0
    return min(max(score, 0.0), 100.0)

def compute_overall_match(job_desc, candidate_profile):
    """Computes combined multifactor match scores.
    
    Weights:
    - Text Similarity: 40%
    - Skills Alignment: 40%
    - Experience Alignment: 20%
    """
    # Extract properties
    job_text = job_desc.description
    job_skills = job_desc.get_skills_list()
    min_exp = job_desc.min_experience
    
    resume_text = candidate_profile.get('raw_text', '')
    cand_skills = candidate_profile.get('skills', [])
    cand_exp = candidate_profile.get('experience_years', 0.0)
    
    # Calculate components
    similarity_score = calculate_text_similarity(job_text, resume_text)
    skill_score = calculate_skill_score(job_skills, cand_skills)
    experience_score = calculate_experience_score(min_exp, cand_exp)
    
    # Weighted average
    overall_score = (0.4 * similarity_score) + (0.4 * skill_score) + (0.2 * experience_score)
    
    return {
        'overall_score': round(overall_score, 2),
        'similarity_score': round(similarity_score, 2),
        'skill_score': round(skill_score, 2),
        'experience_score': round(experience_score, 2)
    }
