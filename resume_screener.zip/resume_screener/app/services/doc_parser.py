import os
import PyPDF2
import docx

def extract_text_from_pdf(filepath):
    """Extracts raw text from a PDF file using PyPDF2."""
    text = ""
    try:
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            num_pages = len(reader.pages)
            for page_num in range(num_pages):
                page = reader.pages[page_num]
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        print(f"Error parsing PDF {filepath}: {str(e)}")
    return text

def extract_text_from_docx(filepath):
    """Extracts raw text from a Word document using python-docx."""
    text = ""
    try:
        doc = docx.Document(filepath)
        # Extract paragraph text
        for paragraph in doc.paragraphs:
            if paragraph.text:
                text += paragraph.text + "\n"
        # Extract text from tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text:
                        text += cell.text + " "
                text += "\n"
    except Exception as e:
        print(f"Error parsing DOCX {filepath}: {str(e)}")
    return text

def parse_document(filepath):
    """Determines file type and extracts all raw text."""
    if not os.path.exists(filepath):
        return ""
        
    ext = filepath.split('.')[-1].lower()
    if ext == 'pdf':
        return extract_text_from_pdf(filepath)
    elif ext == 'docx':
        return extract_text_from_docx(filepath)
    else:
        return ""
