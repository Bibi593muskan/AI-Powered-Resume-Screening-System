from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import db, JobDescription

jobs_bp = Blueprint('jobs', __name__)

@jobs_bp.route('/')
@login_required
def list_jobs():
    user_jobs = JobDescription.query.filter_by(user_id=current_user.id)\
        .order_by(JobDescription.created_at.desc()).all()
    return render_template('jobs/list.html', jobs=user_jobs)

@jobs_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_job():
    if request.method == 'POST':
        title = request.form.get('title')
        department = request.form.get('department')
        description = request.form.get('description')
        min_experience = request.form.get('min_experience')
        required_skills = request.form.get('required_skills')
        education_criteria = request.form.get('education_criteria')
        
        # Validations
        if not title or not description:
            flash('Job Title and Job Description are required.', 'danger')
            return redirect(url_for('jobs.create_job'))
            
        try:
            min_exp_val = int(min_experience) if min_experience else 0
        except ValueError:
            min_exp_val = 0

        new_job = JobDescription(
            title=title,
            department=department,
            description=description,
            min_experience=min_exp_val,
            required_skills=required_skills,
            education_criteria=education_criteria,
            user_id=current_user.id
        )
        
        db.session.add(new_job)
        db.session.commit()
        
        flash('Job posting created successfully!', 'success')
        return redirect(url_for('jobs.list_jobs'))
        
    return render_template('jobs/create.html')

@jobs_bp.route('/<int:job_id>/delete', methods=['POST'])
@login_required
def delete_job(job_id):
    job = JobDescription.query.filter_by(id=job_id, user_id=current_user.id).first_or_404()
    db.session.delete(job)
    db.session.commit()
    flash('Job posting deleted successfully.', 'success')
    return redirect(url_for('jobs.list_jobs'))
