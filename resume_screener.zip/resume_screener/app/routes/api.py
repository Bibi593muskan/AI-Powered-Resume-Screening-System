import os
import csv
import io
import json
from datetime import datetime
from flask import Blueprint, request, jsonify, make_response, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.models import db, JobDescription, ScreeningSession, Candidate, ScreeningResult
from app.services.doc_parser import parse_document
from app.services.nlp_engine import analyze_resume
from app.services.matcher import compute_overall_match

api_bp = Blueprint('api', __name__)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

@api_bp.route('/upload', methods=['POST'])
@login_required
def upload_resumes():
    """Handles bulk uploads and triggers parser/NLP extraction/ML matching dynamically."""
    job_id = request.form.get('job_id')
    run_name = request.form.get('run_name')
    
    if not job_id:
        return jsonify({'error': 'Job Description selection is required.'}), 400
        
    job_desc = JobDescription.query.filter_by(id=job_id, user_id=current_user.id).first()
    if not job_desc:
        return jsonify({'error': 'Invalid Job Description selected.'}), 404
        
    # Default session run name if blank
    if not run_name:
        run_name = f"Screening - {job_desc.title} - {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"
        
    # Verify files
    files = request.files.getlist('resumes')
    if not files or files[0].filename == '':
        return jsonify({'error': 'No resume files uploaded.'}), 400

    # Create ScreeningSession
    session_run = ScreeningSession(
        run_name=run_name,
        job_id=job_id,
        user_id=current_user.id,
        status='Processing'
    )
    db.session.add(session_run)
    db.session.commit()

    processed_count = 0
    errors = []

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            
            # Subdirectory under uploads based on job_id for clean structure
            job_upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], str(job_id))
            os.makedirs(job_upload_dir, exist_ok=True)
            
            # Timestamp to avoid overwrites
            unique_filename = f"{int(datetime.utcnow().timestamp())}_{filename}"
            filepath = os.path.join(job_upload_dir, unique_filename)
            
            try:
                # Save file
                file.save(filepath)
                
                # Step 1: Text extraction
                raw_text = parse_document(filepath)
                if not raw_text.strip():
                    errors.append(f"{file.filename}: No readable text found.")
                    continue
                
                # Step 2: NLP Analysis (Name, contact details, skills, experience)
                nlp_profile = analyze_resume(raw_text)
                
                # Step 3: Save Candidate Record
                candidate = Candidate(
                    filename=filename,
                    filepath=filepath,
                    candidate_name=nlp_profile['name'],
                    email=nlp_profile['email'],
                    phone=nlp_profile['phone'],
                    extracted_text=raw_text,
                    experience_years=nlp_profile['experience_years']
                )
                candidate.set_skills(nlp_profile['skills'])
                candidate.set_education(nlp_profile['education'])
                
                db.session.add(candidate)
                db.session.flush()  # Obtain candidate ID
                
                # Step 4: ML Similarities and scoring computation
                scores = compute_overall_match(job_desc, nlp_profile)
                
                # Step 5: Save Screening Result
                result = ScreeningResult(
                    session_id=session_run.id,
                    candidate_id=candidate.id,
                    overall_score=scores['overall_score'],
                    similarity_score=scores['similarity_score'],
                    skill_score=scores['skill_score'],
                    experience_score=scores['experience_score'],
                    status='Screened'
                )
                db.session.add(result)
                processed_count += 1
                
            except Exception as e:
                errors.append(f"{file.filename}: Exception during screening - {str(e)}")
        else:
            errors.append(f"{file.filename}: File type not supported. Use PDF or DOCX.")

    # Update session status
    if processed_count > 0:
        session_run.status = 'Completed'
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'Successfully screened {processed_count} resumes.',
            'errors': errors,
            'redirect_url': f'/sessions/{session_run.id}'
        })
    else:
        session_run.status = 'Failed'
        db.session.commit()
        return jsonify({
            'success': False,
            'error': 'No resumes could be parsed or matched.',
            'errors': errors
        }), 400


@api_bp.route('/result/<int:result_id>/status', methods=['POST'])
@login_required
def update_status(result_id):
    """Updates candidate screening review status (e.g. Shortlisted, Rejected)."""
    result = ScreeningResult.query.get_or_404(result_id)
    
    # Ensure this result belongs to a session created by the current recruiter
    if result.session.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized access.'}), 403
        
    data = request.get_json() or {}
    new_status = data.get('status')
    
    if new_status not in ['Screened', 'Shortlisted', 'Rejected']:
        return jsonify({'error': 'Invalid status option.'}), 400
        
    result.status = new_status
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'Status updated to {new_status}.',
        'new_status': new_status
    })


@api_bp.route('/session/<int:session_id>/export', methods=['GET'])
@login_required
def export_csv(session_id):
    """Exports screening list of candidate metrics into downloadable CSV."""
    session_run = ScreeningSession.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    results = ScreeningResult.query.filter_by(session_id=session_id)\
        .order_by(ScreeningResult.overall_score.desc()).all()
        
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Header row
    writer.writerow([
        'Rank', 'Candidate Name', 'Email', 'Phone', 'Experience (Years)', 
        'Overall Score (%)', 'Text Similarity (%)', 'Skill Match (%)', 
        'Experience Match (%)', 'Matched Skills', 'Status'
    ])
    
    for i, res in enumerate(results, 1):
        cand = res.candidate
        skills_str = ", ".join(cand.get_skills())
        writer.writerow([
            i, cand.candidate_name, cand.email or 'N/A', cand.phone or 'N/A', 
            cand.experience_years, res.overall_score, res.similarity_score, 
            res.skill_score, res.experience_score, skills_str, res.status
        ])
        
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = f"attachment; filename=screening_report_{session_id}.csv"
    response.headers["Content-type"] = "text/csv"
    return response


@api_bp.route('/analytics/dashboard', methods=['GET'])
@login_required
def get_analytics_data():
    """Generates and provides statistics for the recruiter dashboard charts."""
    # 1. Score distributions
    # Query all overall scores for the current recruiter
    scores_query = db.session.query(ScreeningResult.overall_score)\
        .join(ScreeningSession)\
        .filter(ScreeningSession.user_id == current_user.id).all()
        
    ranges = {
        'Excellent (>=85%)': 0,
        'Good (70-84%)': 0,
        'Average (50-69%)': 0,
        'Poor (<50%)': 0
    }
    
    for (score,) in scores_query:
        if score >= 85:
            ranges['Excellent (>=85%)'] += 1
        elif score >= 70:
            ranges['Good (70-84%)'] += 1
        elif score >= 50:
            ranges['Average (50-69%)'] += 1
        else:
            ranges['Poor (<50%)'] += 1

    # 2. Skill availability (frequencies of matched candidate skills)
    candidates_skills_query = db.session.query(Candidate.skills)\
        .join(ScreeningResult)\
        .join(ScreeningSession)\
        .filter(ScreeningSession.user_id == current_user.id).all()
        
    skills_freq = {}
    for (skills_json,) in candidates_skills_query:
        if skills_json:
            try:
                skills_list = json.loads(skills_json)
                for skill in skills_list:
                    # Clean representation
                    sk_cap = skill.title() if len(skill) > 3 else skill.upper()
                    skills_freq[sk_cap] = skills_freq.get(sk_cap, 0) + 1
            except Exception:
                pass
                
    # Get top 8 skills
    sorted_skills = sorted(skills_freq.items(), key=lambda x: x[1], reverse=True)[:8]
    skills_labels = [s[0] for s in sorted_skills]
    skills_values = [s[1] for s in sorted_skills]
    
    return jsonify({
        'scores_chart': {
            'labels': list(ranges.keys()),
            'data': list(ranges.values())
        },
        'skills_chart': {
            'labels': skills_labels,
            'data': skills_values
        }
    })
