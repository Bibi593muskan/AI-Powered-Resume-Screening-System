from flask import Blueprint, render_template
from flask_login import login_required, current_user
from app.models import db, JobDescription, ScreeningSession, ScreeningResult
from sqlalchemy import func

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@login_required
def index():
    # Gather statistics for the recruiter's account
    total_jobs = JobDescription.query.filter_by(user_id=current_user.id).count()
    
    # Calculate candidate counts and averages using relational joins
    total_screened = db.session.query(func.count(ScreeningResult.id))\
        .join(ScreeningSession)\
        .filter(ScreeningSession.user_id == current_user.id).scalar() or 0
        
    avg_score = db.session.query(func.avg(ScreeningResult.overall_score))\
        .join(ScreeningSession)\
        .filter(ScreeningSession.user_id == current_user.id).scalar() or 0.0
    avg_score = round(float(avg_score), 1)

    total_shortlisted = db.session.query(func.count(ScreeningResult.id))\
        .join(ScreeningSession)\
        .filter(ScreeningSession.user_id == current_user.id, ScreeningResult.status == 'Shortlisted').scalar() or 0

    # Retrieve recent jobs and recent sessions
    recent_jobs = JobDescription.query.filter_by(user_id=current_user.id)\
        .order_by(JobDescription.created_at.desc()).limit(5).all()
        
    recent_sessions = ScreeningSession.query.filter_by(user_id=current_user.id)\
        .order_by(ScreeningSession.run_date.desc()).limit(5).all()

    # Pass everything to render
    return render_template(
        'dashboard.html',
        total_jobs=total_jobs,
        total_screened=total_screened,
        avg_score=avg_score,
        total_shortlisted=total_shortlisted,
        recent_jobs=recent_jobs,
        recent_sessions=recent_sessions
    )
