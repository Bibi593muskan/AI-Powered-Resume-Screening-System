from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import db, ScreeningSession, ScreeningResult

sessions_bp = Blueprint('sessions', __name__)

@sessions_bp.route('/')
@login_required
def history():
    # Fetch all screening sessions associated with the user
    user_sessions = ScreeningSession.query.filter_by(user_id=current_user.id)\
        .order_by(ScreeningSession.run_date.desc()).all()
    return render_template('sessions/history.html', sessions=user_sessions)

@sessions_bp.route('/<int:session_id>')
@login_required
def detail(session_id):
    # Fetch specific session belonging to the user
    session_run = ScreeningSession.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    
    # Retrieve all matched results sorted in descending order of overall_score
    results = ScreeningResult.query.filter_by(session_id=session_id)\
        .order_by(ScreeningResult.overall_score.desc()).all()
        
    return render_template('sessions/detail.html', session=session_run, results=results)

@sessions_bp.route('/<int:session_id>/delete', methods=['POST'])
@login_required
def delete_session(session_id):
    session_run = ScreeningSession.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    db.session.delete(session_run)
    db.session.commit()
    flash('Screening session deleted successfully.', 'success')
    return redirect(url_for('sessions.history'))
