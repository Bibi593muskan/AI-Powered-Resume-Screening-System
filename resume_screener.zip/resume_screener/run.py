from app import create_app

app = create_app()

if __name__ == '__main__':
    # Running Flask app on localhost, port 5000 with debug enabled for development
    app.run(host='127.0.0.1', port=5000, debug=True)
